﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_data_access;
using SanctionCheck.rtsadapter_model.rtsadapter_exception;
using SanctionCheck.rtsadapter_model.rtsadapter_model_bo;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;
using SanctionCheck.rtsadapter_service;

namespace SanctionCheck.rtsadapter_transformer
{
    public class RtsScreenngInput : DtoBoFactory<PrimeRequest, DuedilRequestBO>
    {
       
        
        public DuedilRequestBO toBusninessObject(PrimeRequest request)
        {
            DuedilRequestBO duedilRequest = new DuedilRequestBO();


            try
            {

                SourceDetailBO sourceDetail = new SourceDetailBO();
                SearchAttributesBO searchAttributes = new SearchAttributesBO();
                PartyDetailBO partyDetail = new PartyDetailBO();
                AddressBO address = new AddressBO();

                RtsDataLookupDTO data = new RtsDataLookupDTO();

                RtsDataLookupImpl getData = new RtsDataLookupImpl();
                RtsRequestValidator validate = new RtsRequestValidator();

                data.TransctionCountry = request.Org;
                data.Region = request.Dept;
                data.SanctionRule = request.SanctionRule;

                getData.datalookup(data);

                sourceDetail.organization = request.Org;
                sourceDetail.businessUnit = data.BusinessUnit;
                sourceDetail.region = request.Dept;
                sourceDetail.branch = request.Branch;
                sourceDetail.country = request.Org;
                sourceDetail.source = request.Source;
                sourceDetail.applicationId = data.ApplicationId;
                sourceDetail.orderId = string.Concat(sourceDetail.applicationId, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                duedilRequest.sourceDetail = sourceDetail;
                
              
                searchAttributes.searchDefinition = request.SanctionRule;
                searchAttributes.screeningType = data.ScreeningType;
                searchAttributes.generateTicket = String.Equals(data.GenerateTicket, "True", StringComparison.OrdinalIgnoreCase) ? data.GenerateTicket : "False" ;
                searchAttributes.enableSuppression = "False";
                searchAttributes.applyMisspellingRule = "true";
                duedilRequest.searchAttributes = searchAttributes;

                partyDetail.partyId = string.Concat(data.PartyIdPrefix, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                partyDetail.partyType = "INDIVIDUAL";
                partyDetail.fullName = request.FirstName + " " + request.MiddleName + " " + request.LastName;
                partyDetail.firstName = request.FirstName;
                partyDetail.lastName = request.LastName;
                partyDetail.middleName = request.MiddleName;

                if (!String.IsNullOrEmpty(request.DateOfBirth))
                {
                    DateTime dateValue;
                    string day = request.DateOfBirth.Substring(0, 2);
                    string month = request.DateOfBirth.Substring(2, 2);
                    string year = request.DateOfBirth.Substring(4, 4);
                    partyDetail.dateOfBirth = string.Concat(day, "/", month, "/", year);
                    if (!DateTime.TryParseExact(partyDetail.dateOfBirth, "dd/MM/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dateValue))
                    {
                        throw new InvalidInputException("Incorrect date of birth");
                    }
                }
                address.city = request.City;
                address.country = request.Country;
                address.street = request.Street;
                partyDetail.address = address;

                duedilRequest.partyDetail = partyDetail;
                duedilRequest = validate.validate(duedilRequest);



            }
            catch (InvalidInputException ex)
            {
                throw ex;            
            }
            catch (NullReferenceException ex)
            {
                throw ex;
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return duedilRequest;
        }

        public PrimeRequest toDataTransferObject(DuedilRequestBO request)
        {
 	        throw new NotImplementedException();
        }


        
    }
}

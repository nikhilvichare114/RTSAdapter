﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_transformer
{
    interface BoDtoFactory<DuedilResponseBO,RtsResponseDTO>
    {
        DuedilResponseBO toBusninessObject(RtsResponseDTO response);

        RtsResponseDTO toDataTransferObject(DuedilResponseBO response);
    }
}

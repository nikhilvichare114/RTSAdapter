﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

//Initial Name of the Class was RtsResponseDTO which is changed to PrimeResponse to match up with the nameing convention of old adapter.
namespace SanctionCheck.rtsadapter_model.rtsadapter_model_dto
{
   [DataContract]
   public class PrimeResponse
    {
       private string transId;
       [DataMember(Order=0,EmitDefaultValue=false)]
       public string TransId 
       { 
             get { return transId;} 
             set { transId=value ;} 
       }

       private List<SanctionInfoDTO> matches;
       [DataMember(Order = 1, EmitDefaultValue = false)]
        public List<SanctionInfoDTO> Matches
       {
           get { return matches; }
           set {matches=value; } 
       }

       private MessageOutcome outcome;
       [DataMember(Order = 2, EmitDefaultValue = false)]
        public MessageOutcome Outcome 
       {
           get {return outcome; }
           set { outcome = value; }
       }

       private string message;
       [DataMember(Order = 3, EmitDefaultValue = false)]
        public string Message 
       {
           get { return message; }
           set { message = value; }
       }
    }

    
    public enum MessageOutcome
    {
        
        Failed=1,
        NoMatches=2,
        MatchesFound=3

        
    }
}

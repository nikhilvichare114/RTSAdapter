﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
   public class AddressBO
    {
        public string address1 { get; set; }
        public string address2 { get; set; }
        public string street { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string postalCode { get; set; }
    }
}

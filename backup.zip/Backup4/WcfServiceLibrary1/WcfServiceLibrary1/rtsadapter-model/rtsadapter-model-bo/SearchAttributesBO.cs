﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
    public class SearchAttributesBO
    {
        public string searchDefinition { get; set; }
        public string screeningType { get; set; }
        public string generateTicket { get; set; }
        public string enableSuppression { get; set; }
        public string applyMisspellingRule { get; set; }
        public string mustMatchFields { get; set; }
    }
}

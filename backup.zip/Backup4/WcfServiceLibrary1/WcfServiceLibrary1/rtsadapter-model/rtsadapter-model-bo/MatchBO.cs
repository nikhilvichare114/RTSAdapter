﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
   public class MatchBO
    {
        public string programName { get; set; }
        public string matchName { get; set; }
        public string nameOfSDN { get; set; }
        public string partyType { get; set; }
        public string titleOfSDN { get; set; }
        public string score { get; set; }
        public string matchText { get; set; }
        public string matchType { get; set; }
        public string remarks { get; set; }
        public string info { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionCheck.rtsadapter_data_access
{
   public class RtsDataLookupImpl : RtsDataLookup<RtsDataLookupDTO>
    {
        public RtsDataLookupDTO datalookup(RtsDataLookupDTO data)
        {
            
            string connectionString = ConfigurationManager.ConnectionStrings["RtsDataLookup"].ConnectionString;
            var connection = new SqlConnection(connectionString);
            
            try
            {
                
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                    string procedureName = ConfigurationManager.AppSettings["ProcedureName"];
                    SqlCommand cmd = new SqlCommand(procedureName, connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@TranscctionCountry", data.TransctionCountry);
                    cmd.Parameters.AddWithValue("@Region", data.Region);
                    cmd.Parameters.AddWithValue("@SanctionRule", data.SanctionRule);

                    cmd.Parameters.Add("@BusinessUnit", SqlDbType.VarChar, 20);
                    cmd.Parameters["@BusinessUnit"].Direction = ParameterDirection.Output;

                    cmd.Parameters.Add("@ApplicationId", SqlDbType.VarChar, 20);
                    cmd.Parameters["@ApplicationId"].Direction = ParameterDirection.Output;
                   
                    cmd.Parameters.Add("@ScreeningType", SqlDbType.VarChar, 20);
                    cmd.Parameters["@ScreeningType"].Direction = ParameterDirection.Output;

                    cmd.Parameters.Add("@GenerateTicket", SqlDbType.Bit);
                    cmd.Parameters["@GenerateTicket"].Direction = ParameterDirection.Output;


                    cmd.Parameters.Add("@PartyIdPrefix", SqlDbType.VarChar, 20);
                    cmd.Parameters["@PartyIdPrefix"].Direction = ParameterDirection.Output;
                    
                    cmd.ExecuteNonQuery();

                    data.BusinessUnit = cmd.Parameters["@BusinessUnit"].Value.ToString();

                    data.ApplicationId = cmd.Parameters["@ApplicationId"].Value.ToString();

                    data.ScreeningType = cmd.Parameters["@ScreeningType"].Value.ToString();

                    data.GenerateTicket = cmd.Parameters["@GenerateTicket"].Value.ToString();
                    

                    data.PartyIdPrefix = cmd.Parameters["@PartyIdPrefix"].Value.ToString();

                }
                
            }

            catch(SqlException ex)
            {
                throw ex;
            
            }
            catch (Exception ex)
            {
                
                throw ex;
            }
            finally
            {

                connection.Close();
                
            }

            return data;
        }
    }
}

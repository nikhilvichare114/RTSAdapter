﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;
using SanctionCheck.rtsadapter_model;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;
using SanctionCheck.rtsadapter_transformer;
using SanctionCheck.rtsadapter_service;
using System.Data.SqlClient;
using SanctionCheck.rtsadapter_model.rtsadapter_exception;


namespace SanctionCheck
{
    
   
    public class SanctionCheck : SanctionCheckService
    {

        public PrimeResponse GetCustomerMatch(PrimeRequest PrimeReq)
        {
            PrimeResponse service = new PrimeResponse();
            RtsRequestValidator rtsRequestValidator = new RtsRequestValidator();
            try
            {

                RtsRequestValidator validator = new RtsRequestValidator();
                validator.validate(PrimeReq);

                RtsScreeningImpl rtsScreeningImpl = new RtsScreeningImpl();
                service = rtsScreeningImpl.screening(PrimeReq);

            }

            catch (InvalidInputException ex)
            {
                
                return rtsRequestValidator.ErrorResponse(ex);
                
            }


            catch(NullReferenceException ex)
            {
                return rtsRequestValidator.ErrorResponse(ex);
            }

            catch (SqlException ex)
            {
                
                return rtsRequestValidator.ErrorResponse(ex);
            
            }

            catch (HttpRequestException ex)
            {
                
                 return rtsRequestValidator.ErrorResponse(ex);

            }

            catch (Exception ex)
            {
                return rtsRequestValidator.ErrorResponse(ex);


            }
            finally
            {

            }
            return service;
        }
    }
}

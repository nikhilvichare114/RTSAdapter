﻿// Copyright (c) 2017 Travelex Ltd
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SanctionAdapter.rtsadapter_data_access;
using SanctionAdapter.rtsadapter_model;
using SanctionAdapter.rtsadapter_model.rtsadapter_exception;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_transformer;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using System.Security.Cryptography.X509Certificates;
using System.Diagnostics;

namespace SanctionAdapter.rtsadapter_service
{
   public class RtsScreening : IRtsScreening<RtsRequestDTO> 
    {
      
        /// <summary>
        /// The Screening method is to call the Duedil Service and provide the output that is expected by RTS Client .
        /// Duedil is a service which performs the Sanction and PEP check for the users.
        /// The details of the user are sent by RTS Client.
        /// </summary>
        /// <param name="request">Data Transfer Object of RTS client Request</param>
        /// <returns>Data Transfer Object of RTS client Response</returns>
        /// 

        private IDtoBoFactory<RtsRequestDTO, DuedilRequestBO> _rtsScreeningInput;

        private IBoDtoFactory<DuedilResponseBO, RtsResponseDTO> _rtsScreeningOutput;
        


        public RtsScreening(IDtoBoFactory<RtsRequestDTO, DuedilRequestBO> rtsScreeningInput, IBoDtoFactory<DuedilResponseBO, RtsResponseDTO> rtsScreeningOutput)
        {
            _rtsScreeningInput = rtsScreeningInput;
            _rtsScreeningOutput = rtsScreeningOutput;

        }

        public RtsResponseDTO screening(RtsRequestDTO request)
        {
            RtsResponseDTO response = new RtsResponseDTO();
            DuedilResponseBO service = new DuedilResponseBO();
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.DefaultConnectionLimit = 9999;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            //ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls12 ;
            
            WebRequestHandler handler = new WebRequestHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            var certificate = new X509Certificate2Collection();
            string certPath = ConfigurationManager.AppSettings["CertPath"];
            string certPassword = ConfigurationManager.AppSettings["CertPassword"];

            certificate.Import(certPath, certPassword, X509KeyStorageFlags.DefaultKeySet| X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
            handler.ClientCertificates.AddRange(certificate);
            //HttpClient client = new HttpClient(handler);
            using (HttpClient client = new HttpClient(handler))
            {

                try
                {
                    var duedilInputRequest = _rtsScreeningInput.toBusninessObject(request);
                    string URL = ConfigurationManager.AppSettings["MockDuedil"];
                    string cacheControl = ConfigurationManager.AppSettings["cache-control"];

                    client.BaseAddress = new Uri(URL);
                    client.DefaultRequestHeaders.Add("cache-control", cacheControl);
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "App");
                    HttpContent content = new StringContent(JsonConvert.SerializeObject(duedilInputRequest), Encoding.UTF8, "application/json");

                    var duedilResponse = client.PostAsync(URL, content).Result;
                    
                    string duedilResponseResult = duedilResponse.Content.ReadAsStringAsync().Result.ToString();
                    int statusCode = (int)duedilResponse.StatusCode;

                    if (statusCode.Equals(200) || statusCode.Equals(202))
                    {

                        service = JsonConvert.DeserializeObject<DuedilResponseBO>(duedilResponseResult);


                        response = _rtsScreeningOutput.toDataTransferObject(service);
                    }
                    else
                    {
                        throw new HttpRequestException("Duedil Response Error : " + " " + duedilResponseResult);
                    }


                }
                catch (InvalidInputException ex)
                {
                    throw ex;
                }
                catch (NullReferenceException ex)
                {

                    throw ex;
                }

                catch (SqlException ex)
                {
                    throw ex;

                }

                catch (HttpRequestException ex)
                {
                    throw ex;

                }

                catch (AggregateException ex)
                {
                    if (ex.InnerException.InnerException != null)
                    {
                        throw ex.InnerException.InnerException;
                    }
                    else
                    {
                        throw ex.InnerException;

                    }
                }

                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    //if (client != null)
                    //{

                    //    client.Dispose();

                    //}
                }
            }
            return response;
        }
    }
}

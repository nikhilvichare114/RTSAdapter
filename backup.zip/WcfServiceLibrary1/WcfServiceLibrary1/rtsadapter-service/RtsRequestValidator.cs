﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;
using SanctionCheck.rtsadapter_model.rtsadapter_exception;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using SanctionCheck.rtsadapter_model.rtsadapter_model_bo;
using System.Text.RegularExpressions;
using System.Globalization;

namespace SanctionCheck.rtsadapter_service
{
    class RtsRequestValidator
    {
        public void validate(PrimeRequest request)
        {
            Regex regex = new Regex("^[0-9]*$");
            if (String.IsNullOrEmpty(request.FirstName))
            {
                throw new InvalidInputException("Missing First Name");
            }
            else if (String.IsNullOrEmpty(request.Dept))
            {
                throw new InvalidInputException("Missing Department");
            }

            else if (String.IsNullOrEmpty(request.Branch))
            {
                throw new InvalidInputException("Missing Branch");
            }
            else if (String.IsNullOrEmpty(request.Source))
            {
                throw new InvalidInputException("Missing Source");
            }
            else if (String.IsNullOrEmpty(request.SanctionRule))
            {
                throw new InvalidInputException("Missing sanctionRule");
            }
           
                   
        
        }

        public DuedilRequestBO validate(DuedilRequestBO duedilRequest)
        {
            
            if (String.IsNullOrEmpty(duedilRequest.sourceDetail.businessUnit))
            {
                throw new InvalidInputException("Missing Business Unit");
            }
            else if (String.IsNullOrEmpty(duedilRequest.sourceDetail.applicationId) || !String.Equals(duedilRequest.sourceDetail.applicationId,"R03"))
            {
                throw new InvalidInputException("Missing Application Id Or Incorrect Application Id");
            }
           
            else if (String.IsNullOrEmpty(duedilRequest.sourceDetail.orderId))
            {
                throw new InvalidInputException("Missing OrderId");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.searchDefinition))
            {
                throw new InvalidInputException("Missing SearchDefinition");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.screeningType) || (!String.Equals(duedilRequest.searchAttributes.screeningType, "PEP") && !String.Equals(duedilRequest.searchAttributes.screeningType, "SANCTION")))
            {
                throw new InvalidInputException("Missing Screening Type");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.generateTicket))
            {
                throw new InvalidInputException("Missing generateTicket");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.enableSuppression))
            {
                throw new InvalidInputException("Missing enableSuppression");

            }
            else if (String.IsNullOrEmpty(duedilRequest.partyDetail.partyId) || duedilRequest.partyDetail.partyId.Length > 50)
            {
                throw new InvalidInputException("Missing partyId or length of partyId greater than 50 char");
                
            }
           
            else if (String.IsNullOrEmpty(duedilRequest.partyDetail.partyType) )
            {
                duedilRequest.partyDetail.partyType = "INDIVIDUAL";
                
            }

            return duedilRequest;
        }

        public PrimeResponse ErrorResponse(Exception ex)
        {
               PrimeResponse service = new PrimeResponse();
       

                string transId="E" + "-" + DateTime.Now.ToString("yyyyMMddHHmmssfff");

                service.Outcome = MessageOutcome.Failed;
                //service.Message = transId + " " + "Sanction/PEP check unsuccessful. Please contact Security Administrator";
                service.Message = ex.Message;
                return service;

            

        
        }

    }
}

﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_model.rtsadapter_exception;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using System.Text.RegularExpressions;
using System.Globalization;
using System.Configuration;

namespace SanctionAdapter.rtsadapter_service
{
    public class RtsRequestValidator : IRtsRequestValidator<RtsRequestDTO, DuedilRequestBO>
    {
       /// <summary>
       /// It is used to validate the input from RTS Client, it throws an exception if the validation fails.
       /// </summary>
       /// <param name="request">Data Transfer Object of type RTS request</param>
        public void validate(RtsRequestDTO request)
        {
            
            if (String.IsNullOrEmpty(request.FirstName))
            {
                throw new InvalidInputException("Missing First Name");
            }
            else if (String.IsNullOrEmpty(request.Dept))
            {
                throw new InvalidInputException("Missing Department");
            }

            else if (String.IsNullOrEmpty(request.Org))
            {
                throw new InvalidInputException("Missing Org");
            }

            else if (String.IsNullOrEmpty(request.Branch))
            {
                throw new InvalidInputException("Missing Branch");
            }
            else if (String.IsNullOrEmpty(request.Source))
            {
                throw new InvalidInputException("Missing Source");
            }
            else if (String.IsNullOrEmpty(request.SanctionRule))
            {
                throw new InvalidInputException("Missing sanctionRule");
            }
           
                   
        
        }


       /// <summary>
        ///  It is used to validate the input that is generated after the Lookup and before sent to Duedil, it throws an exception if the validation fails.
       /// </summary>
       /// <param name="duedilRequest">Business Object of Type Duedils's Request.</param>
        /// <returns>Business Object of Type Duedils's Request.</returns>
        public DuedilRequestBO validate(DuedilRequestBO duedilRequest)
        {
            
            if (String.IsNullOrEmpty(duedilRequest.sourceDetail.businessUnit))
            {
                throw new InvalidInputException("Missing Business Unit");
            }
            else if (String.IsNullOrEmpty(duedilRequest.sourceDetail.applicationId) )
            {
                
                throw new InvalidInputException("Missing Application Id Or Incorrect Application Id");
            }
           
            else if (String.IsNullOrEmpty(duedilRequest.sourceDetail.orderId))
            {
                throw new InvalidInputException("Missing OrderId");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.searchDefinition))
            {
                throw new InvalidInputException("Missing SearchDefinition");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.screeningType) || (!String.Equals(duedilRequest.searchAttributes.screeningType, "PEP") && !String.Equals(duedilRequest.searchAttributes.screeningType, "SANCTION")))
            {
              
                throw new InvalidInputException("Missing Screening Type");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.generateTicket))
            {
                throw new InvalidInputException("Missing generateTicket");
            }
            else if (String.IsNullOrEmpty(duedilRequest.searchAttributes.enableSuppression))
            {
                throw new InvalidInputException("Missing enableSuppression");

            }
            else if (String.IsNullOrEmpty(duedilRequest.partyDetail.partyId) || duedilRequest.partyDetail.partyId.Length > 50)
            {
                throw new InvalidInputException("Missing partyId or length of partyId greater than 50 char");
                
            }
           
            else if (String.IsNullOrEmpty(duedilRequest.partyDetail.partyType) )
            {
                duedilRequest.partyDetail.partyType = ConfigurationManager.AppSettings["PartyType"];
                
            }

            return duedilRequest;
        }

        public RtsResponseDTO ErrorResponse(Exception ex)
        {
               RtsResponseDTO service = new RtsResponseDTO();
       

                string transId="E" + "-" + DateTime.Now.ToString("yyyyMMddHHmmssfff");

                service.Outcome = MessageOutcome.Failed;
                service.Message = ex.Message;
                return service;

            

        
        }

    }
}

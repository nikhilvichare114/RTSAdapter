﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace SanctionAdapter.rtsadapter_service
{
    public sealed class RtsCertificateHandler
    {
        static WebRequestHandler handler = null;


        private static RtsCertificateHandler instance = null;
        private static readonly object obj = new object();
        
        private RtsCertificateHandler()
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            handler = new WebRequestHandler();
            handler.ClientCertificateOptions = ClientCertificateOption.Manual;
            var certificate = new X509Certificate2Collection();
            string certPath = ConfigurationManager.AppSettings["CertPath"];
            string certPassword = ConfigurationManager.AppSettings["CertPassword"];

            certificate.Import(certPath, certPassword, X509KeyStorageFlags.DefaultKeySet | X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
            handler.ClientCertificates.AddRange(certificate);
            
        }


        public static WebRequestHandler GetInstance
        {
           get
            {

                if (instance == null)
                {
                    lock (obj)
                    {
                        if (instance == null)
                        {
                            instance = new RtsCertificateHandler();

                        }
                    }
                }
                return handler;
            }
        }

     }
}

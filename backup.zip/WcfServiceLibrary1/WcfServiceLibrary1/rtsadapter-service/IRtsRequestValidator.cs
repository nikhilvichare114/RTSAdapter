﻿using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_service
{
  public  interface IRtsRequestValidator<RtsRequestDTO, DuedilRequestBO>
    {

        void validate(RtsRequestDTO request);

        DuedilRequestBO validate(DuedilRequestBO duedilRequest);
    }
}

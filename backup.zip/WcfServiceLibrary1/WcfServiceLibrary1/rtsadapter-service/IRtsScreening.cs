﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionAdapter.rtsadapter_model;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionAdapter.rtsadapter_service
{
    public interface IRtsScreening<RtsRequestDTO>
    {
        RtsResponseDTO screening(RtsRequestDTO request);
    }

}

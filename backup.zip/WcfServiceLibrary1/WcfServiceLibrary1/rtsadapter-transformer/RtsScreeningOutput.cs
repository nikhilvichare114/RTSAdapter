// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionAdapter.rtsadapter_data_access;
using SanctionAdapter.rtsadapter_model;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionAdapter.rtsadapter_transformer
{
    public class RtsScreenngOutput : IBoDtoFactory<DuedilResponseBO, RtsResponseDTO>
    {
        public DuedilResponseBO toBusninessObject(RtsResponseDTO response)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Converts the Input Response from Duedil to Response of RTS Client
        /// </summary>
        /// <param name="response">Business Object of Duedil </param>
        /// <returns>Data Transfer Object of RTS Client</returns>
        public RtsResponseDTO toDataTransferObject(DuedilResponseBO response)
        {
            RtsResponseDTO rtsResponse = new RtsResponseDTO();
            List<SanctionInfoDTO> sanctionInfo = new List<SanctionInfoDTO>();
           
            try
            {
                if (response.Equals(null))
                {
                    throw new NullReferenceException();

                }
                else
                {
                    rtsResponse.TransId = response.TrackingId;
                    foreach (MatchBO match in response.Matches)
                    {
                        SanctionInfoDTO sanctionData = new SanctionInfoDTO();
                        sanctionData.MatchName = match.matchName;
                        sanctionData.ListType = match.programName;
                        sanctionData.Remarks = match.remarks;
                        sanctionInfo.Add(sanctionData);

                    }
                    rtsResponse.Matches = sanctionInfo;

                    if (response.MatchCount > 0)
                    {
                        rtsResponse.Outcome = MessageOutcome.MatchesFound;
                        rtsResponse.Message = "Web Service Ok";
                    }
                    else
                    {
                        rtsResponse.Outcome = MessageOutcome.NoMatches;
                        rtsResponse.Message = "Web Service Ok";
                    }

                }
            }

            catch (NullReferenceException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }
            
            return rtsResponse;
        }
    }
}
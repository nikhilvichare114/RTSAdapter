﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_transformer
{
   public interface IBoDtoFactory<DuedilResponseBO,RtsResponseDTO>
    {
        DuedilResponseBO toBusninessObject(RtsResponseDTO response);

        RtsResponseDTO toDataTransferObject(DuedilResponseBO response);
    }
}

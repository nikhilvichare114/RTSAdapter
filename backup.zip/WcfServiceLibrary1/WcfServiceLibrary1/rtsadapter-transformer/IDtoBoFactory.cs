﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_transformer
{
   public interface IDtoBoFactory<RtsRequestDTO,DuedilRequestBO>
    {
         DuedilRequestBO toBusninessObject(RtsRequestDTO request);

         RtsRequestDTO toDataTransferObject(DuedilRequestBO request);
    }
}

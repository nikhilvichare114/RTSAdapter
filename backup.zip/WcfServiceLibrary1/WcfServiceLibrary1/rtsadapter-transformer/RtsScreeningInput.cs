﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionAdapter.rtsadapter_data_access;
using SanctionAdapter.rtsadapter_model.rtsadapter_exception;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_service;
using System.Configuration;

namespace SanctionAdapter.rtsadapter_transformer
{
    public class RtsScreenngInput : IDtoBoFactory<RtsRequestDTO, DuedilRequestBO>
    {
       
        /// <summary>
        /// It Converts the input from RTS Client into a Dusedil Service specific Business Object. 
        /// </summary>
        /// <param name="request">Its a Data Transfer Object of type RTS client Request</param>
        /// <returns>Reutrns into Business Object of type Duedil Service</returns>
        /// 


        private IRtsDataLookup<RtsDataLookupDTO> _getData;
        private IRtsRequestValidator<RtsRequestDTO, DuedilRequestBO> _validate;

        public RtsScreenngInput(IRtsDataLookup<RtsDataLookupDTO> getData, IRtsRequestValidator<RtsRequestDTO, DuedilRequestBO> validate)
        {
            _getData = getData;

            _validate = validate;
        }
        
        public virtual DuedilRequestBO toBusninessObject(RtsRequestDTO request)
        {
            DuedilRequestBO duedilRequest = new DuedilRequestBO();


            try
            {

                SourceDetailBO sourceDetail = new SourceDetailBO();
                SearchAttributesBO searchAttributes = new SearchAttributesBO();
                PartyDetailBO partyDetail = new PartyDetailBO();
                AddressBO address = new AddressBO();
              
                RtsDataLookupDTO data = new RtsDataLookupDTO();
                
                

                data.TransctionCountry = request.Org;
                data.Region = request.Dept;
                data.SanctionRule = request.SanctionRule;

                _getData.DataLookup(data);

                sourceDetail.organization = request.Org;
                sourceDetail.businessUnit = data.BusinessUnit;
                sourceDetail.region = request.Dept;
                sourceDetail.branch = request.Branch;
                sourceDetail.country = request.Org;
                sourceDetail.source = request.Source;
                sourceDetail.applicationId = data.ApplicationId;
                sourceDetail.orderId = string.Concat(sourceDetail.applicationId, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                duedilRequest.sourceDetail = sourceDetail;
                
              
                searchAttributes.searchDefinition = request.SanctionRule;
                searchAttributes.screeningType = data.ScreeningType;
                searchAttributes.generateTicket = String.Equals(data.GenerateTicket, "True", StringComparison.OrdinalIgnoreCase) ? data.GenerateTicket : "False" ;
                searchAttributes.enableSuppression = "False";
                searchAttributes.applyMisspellingRule = "true";
                duedilRequest.searchAttributes = searchAttributes;

                partyDetail.partyId = string.Concat(data.PartyIdPrefix, DateTime.Now.ToString("yyyyMMddHHmmssfff"));
                partyDetail.partyType = ConfigurationManager.AppSettings["PartyType"]; 
                partyDetail.fullName = request.FirstName + " " + request.MiddleName + " " + request.LastName;
                partyDetail.firstName = request.FirstName;
                partyDetail.lastName = request.LastName;
                partyDetail.middleName = request.MiddleName;

                if (!String.IsNullOrEmpty(request.DateOfBirth))
                {
                    
                    DateTime dateValue;

                    if (!DateTime.TryParseExact(request.DateOfBirth, "dd/MM/yyyy", new CultureInfo("en-US"), DateTimeStyles.None, out dateValue))
                    {
                        throw new InvalidInputException("Incorrect date of birth");
                    }

                    partyDetail.dateOfBirth = dateValue.ToString("dd/MM/yyyy");
                   
                }
                address.city = request.City;
                address.country = request.Country;
                address.street = request.Street;
                partyDetail.address = address;

                duedilRequest.partyDetail = partyDetail;
                duedilRequest = _validate.validate(duedilRequest);



            }
            catch (InvalidInputException ex)
            {
                throw ex;            
            }
            catch (NullReferenceException ex)
            {
                throw ex;
            }

            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return duedilRequest;
        }

        public RtsRequestDTO toDataTransferObject(DuedilRequestBO request)
        {
 	        throw new NotImplementedException();
        }


        
    }
}

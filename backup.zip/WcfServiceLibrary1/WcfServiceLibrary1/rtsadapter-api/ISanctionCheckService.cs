﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using SanctionAdapter.rtsadapter_model;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionAdapter
{
    
    [ServiceContract]
    public interface ISanctionCheckService
    {
        
        [OperationContract]
        RtsResponseDTO GetCustomerMatch(RtsRequestDTO PrimeReq);

    }


 }
   


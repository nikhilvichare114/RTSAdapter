﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using SanctionCheck.rtsadapter_model;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionCheck
{
    
    [ServiceContract]
    public interface SanctionCheckService
    {
        
        [OperationContract]
        PrimeResponse GetCustomerMatch(PrimeRequest PrimeReq);

    }


 }
   


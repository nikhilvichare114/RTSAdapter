﻿// Copyright (c) 2017 Travelex Ltd
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Net.Http;
using System.Net.Http.Headers;
using SanctionAdapter.rtsadapter_model;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_transformer;
using SanctionAdapter.rtsadapter_service;
using System.Data.SqlClient;
using SanctionAdapter.rtsadapter_model.rtsadapter_exception;
using SanctionAdapter.rtsadapter_data_access;


namespace SanctionAdapter
{


    public class SanctionCheckService : ISanctionCheckService
    {
        /// <summary>
        /// The method calls the validator and screening menthods internally to validate the input and get the required output by the client which invokes this method
        /// </summary>
        /// <param name="PrimeReq">Data Transfer Object of RTS client Request</param>
        /// <returns>Data Transfer Object of RTS client Response</returns>
        /// 


      

        public RtsResponseDTO GetCustomerMatch(RtsRequestDTO PrimeReq)
        {
            RtsResponseDTO service = new RtsResponseDTO();
            RtsRequestValidator rtsRequestValidator = new RtsRequestValidator();
            try
            {

                RtsRequestValidator validator = new RtsRequestValidator();
                validator.validate(PrimeReq);

                RtsScreening rtsScreeningImpl = new RtsScreening(new RtsScreenngInput(new RtsDataLookup(), validator), new RtsScreenngOutput());
               
                service = rtsScreeningImpl.screening(PrimeReq);

            }

            catch (InvalidInputException ex)
            {
                
                return rtsRequestValidator.ErrorResponse(ex);
                
            }


            catch(NullReferenceException ex)
            {
                return rtsRequestValidator.ErrorResponse(ex);
            }

            catch (SqlException ex)
            {
                
                return rtsRequestValidator.ErrorResponse(ex);
            
            }

            catch (HttpRequestException ex)
            {
                
                 return rtsRequestValidator.ErrorResponse(ex);

            }

            catch (Exception ex)
            {
                return rtsRequestValidator.ErrorResponse(ex);


            }
            finally
            {

            }
            return service;
        }
    }
}

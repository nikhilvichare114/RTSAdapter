﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_bo
{
    /// <summary>
    /// Business Object to get Users Identification Details , it is used inside PartyDetailsBO
    /// </summary>
   public class IdentificationDetailsBO
    {

        public string issueCountry { get; set; }
        public string type { get; set; }
        public string value { get; set; }
    }
}

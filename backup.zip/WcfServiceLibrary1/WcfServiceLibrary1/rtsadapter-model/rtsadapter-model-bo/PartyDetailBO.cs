﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_bo
{
    /// <summary>
    /// Business Object to get Users Details to perform business logic over it, and it is used inside DuedilRequestBO.
    /// </summary>
   public class PartyDetailBO
    {
        public string partyId { get; set; }
        public string partyType { get; set; }
        public string fullName { get; set; }
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public string dateOfBirth { get; set; }
        public AddressBO address { get; set; }
        public IdentificationDetailsBO[] identificationDetails { get; set; }
    }
}

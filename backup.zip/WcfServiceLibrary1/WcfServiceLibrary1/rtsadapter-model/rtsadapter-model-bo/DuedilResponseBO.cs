﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_model.rtsadapter_model_bo;

namespace SanctionCheck.rtsadapter_model
{
    
    public class DuedilResponseBO
    {
     
       
        public string TrackingId { get; set; }

        
        public string TicketId { get; set; }

        
        public int MatchCount { get; set; }

        
        public MatchBO[] Matches { get; set; }
    }


}

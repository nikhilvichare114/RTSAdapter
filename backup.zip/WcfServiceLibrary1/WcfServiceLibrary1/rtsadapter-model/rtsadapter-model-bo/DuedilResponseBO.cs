﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;

namespace SanctionAdapter.rtsadapter_model
{
    /// <summary>
    /// Business Object for Duedil's Response.
    /// </summary>
    
    public class DuedilResponseBO
    {
     
       
        public string TrackingId { get; set; }

        
        public string TicketId { get; set; }

        
        public int MatchCount { get; set; }

        
        public MatchBO[] Matches { get; set; }
    }


}

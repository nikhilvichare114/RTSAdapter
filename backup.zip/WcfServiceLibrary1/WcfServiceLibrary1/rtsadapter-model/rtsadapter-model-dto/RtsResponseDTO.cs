﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;


namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_dto
{
    /// <summary>
    /// Data Transfer Object to send the RTS Response.
    /// </summary>
   [DataContract]
   public class RtsResponseDTO
    {
       private string transId;
       [DataMember(Order=0,EmitDefaultValue=false)]
       public string TransId 
       { 
             get { return transId;} 
             set { transId=value ;} 
       }

       private List<SanctionInfoDTO> matches;
       [DataMember(Order = 1, EmitDefaultValue = false)]
        public List<SanctionInfoDTO> Matches
       {
           get { return matches; }
           set {matches=value; } 
       }

       private MessageOutcome outcome;
       [DataMember(Order = 2, EmitDefaultValue = false)]
        public MessageOutcome Outcome 
       {
           get {return outcome; }
           set { outcome = value; }
       }

       private string message;
       [DataMember(Order = 3, EmitDefaultValue = false)]
        public string Message 
       {
           get { return message; }
           set { message = value; }
       }
    }

   /// <summary>
   /// Enumaration for the Kind of message outcome recevied from Duedil, used inside RtsResponseDTO
   /// </summary>
    
    public enum MessageOutcome
    {
        
        Failed=1,
        NoMatches=2,
        MatchesFound=3

        
    }
}

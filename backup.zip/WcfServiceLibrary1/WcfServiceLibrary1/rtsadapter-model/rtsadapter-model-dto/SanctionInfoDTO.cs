﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_dto
{
    /// <summary>
    /// Data Transfer Object to hold the Sanction info of the User, it is used inside RtsResponseDTO.
    /// </summary>
    public class SanctionInfoDTO
    {
        
        public string MatchName{get;set;}
        public string ListType{get;set;}
        public string Remarks{get;set;}

    }
}

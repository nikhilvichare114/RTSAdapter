﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;


namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_dto
{
    /// <summary>
    /// Data Transfer Object to receive the RTS Request.
    /// </summary>
   
    [DataContract(Namespace = "http://tempuri.org/")]
    public class RtsRequestDTO
    {
        private string firstName;
        [DataMember(Order=0)]
        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }

        }


        private string middleName;
        [DataMember(Order=1)]
        public string MiddleName
        {
            get { return middleName; }
            set { middleName = value; }
        }


        private string lastName;
        [DataMember(Order=2)]
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }


        private string dateOfBirth;
        [DataMember(Order = 3)]
        public string DateOfBirth
        {
            get { return dateOfBirth; }
            set { dateOfBirth = value; }
        }


        private string street;
        [DataMember(Order = 4)]
        public string Street
        {
            get { return street; }
            set { street = value; }
        }



        private string city;
        [DataMember(Order = 5)]
        public string City
        {
            get { return city; }
            set { city = value; }
        }



        private string country;
        [DataMember(Order = 6)]
        public string Country
        {
            get { return country; }
            set { country = value; }
        }


        private string user;
        [DataMember(Order = 7)]
        public string User
        {
            get { return user; }
            set { user = value; }
        }



        private string password;
        [DataMember(Order = 8)]
        public string Password
        {
            get { return password; }
            set { password = value; }
        }


        private string org;
        [DataMember(Order = 9)]
        public string Org
        {
            get { return org; }
            set { org = value; }
        }


        private string branch;
        [DataMember(Order = 10)]
        public string Branch
        {
            get { return branch; }
            set { branch = value; }
        }


        private string dept;
        [DataMember(Order = 11)]
        public string Dept
        {
            get { return dept; }
            set { dept = value; }
        }


        private string source;
        [DataMember(Order = 12)]
        public string Source
        {
            get { return source; }
            set { source = value; }
        }


        private string sanctionRule;
        [DataMember(Order = 13)]
        public string SanctionRule
        {
            get { return sanctionRule; }
            set { sanctionRule = value; }
        }

        
    }      
    
    
}

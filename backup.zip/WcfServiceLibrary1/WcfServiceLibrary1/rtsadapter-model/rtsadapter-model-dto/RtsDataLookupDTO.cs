﻿// Copyright (c) 2017 Travelex Ltd
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionAdapter.rtsadapter_model.rtsadapter_model_dto
{
    /// <summary>
    /// Data Transfer Object to receive the Lookup data from DataBase.
    /// </summary>
  public  class RtsDataLookupDTO
    {

    public string TransactionCountry { get; set; }

	public string Region {get;set;} 

	public string SanctionRule {get;set;} 

	public string BusinessUnit {get;set;} 

	public string ApplicationId {get;set;}

	public string ScreeningType {get;set;}

	public string GenerateTicket {get;set;}

	public string PartyIdPrefix  {get;set;}


    
    }
}

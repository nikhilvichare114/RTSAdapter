﻿// Copyright (c) 2017 Travelex Ltd
using System;
//using NUnit.Framework;
using Moq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_transformer;
using SanctionAdapter.rtsadapter_data_access;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_service;
using SanctionAdapter.rtsadapter_model;
using System.Text;
using System.Net;
using System.Net.Http;
using System.Web;



namespace UnitTestProject1
{
    [TestClass]
    public class TestRtsScreeningInput
    {
        public RtsResponseDTO response;
        public DuedilRequestBO duedilRequest;
        public RtsRequestDTO request;
        public RtsResponseDTO output;
        public SanctionInfoDTO matches;
        public PartyDetailBO partyDetail;
        public SourceDetailBO sourceDetail;
        public AddressBO address;
        public IdentificationDetailsBO identificationDetails;
        public RtsDataLookupDTO data;
        public SearchAttributesBO searchAttributes;
        

        [TestInitialize]
        public void setup()
        {
            response = new RtsResponseDTO();
            duedilRequest = new DuedilRequestBO();
            
            
            request = new RtsRequestDTO();
            output = new RtsResponseDTO();
            matches = new SanctionInfoDTO();
            partyDetail = new PartyDetailBO();
            sourceDetail = new SourceDetailBO();
            address = new AddressBO();
            identificationDetails = new IdentificationDetailsBO();
            data = new RtsDataLookupDTO();
            

            searchAttributes = new SearchAttributesBO();
            List<SanctionInfoDTO> sanctionInfo = new List<SanctionInfoDTO>();
            

            partyDetail.firstName = "Ali";
            partyDetail.fullName = "Ali";
            partyDetail.partyType = "INDIVIDUAL";
            partyDetail.partyId = "1234";
            partyDetail.address = address;
            partyDetail.identificationDetails = null;

            sourceDetail.branch = "RTS";
            sourceDetail.country = "UK";
            sourceDetail.organization = "EU Sanctions";
            sourceDetail.businessUnit = "1_Europe";
            sourceDetail.region = "London";
            sourceDetail.applicationId = "R03";
            sourceDetail.orderId = "101";
            sourceDetail.source = "RTS";



            searchAttributes.searchDefinition = "EUSanction";
            searchAttributes.screeningType = "SANCTION";
            searchAttributes.generateTicket = "true";
            searchAttributes.enableSuppression = "false";
            searchAttributes.applyMisspellingRule = "false";
            searchAttributes.mustMatchFields = "a";


            duedilRequest.partyDetail = partyDetail;
            duedilRequest.searchAttributes = searchAttributes;
            duedilRequest.sourceDetail = sourceDetail;


            
            matches.ListType = "Sanctions";
            matches.MatchName = "test";
            matches.Remarks = "hit";
            sanctionInfo.Add(matches);
            response.Matches = sanctionInfo;
            response.Message = "Web Service Ok";
            response.Outcome = MessageOutcome.MatchesFound;
            response.TransId = "1234";


            request.Branch = "RTS";
            request.Dept = "EU";
            request.FirstName = "ABC";
            request.Org = "Europe";
            request.SanctionRule = "EU Sanctions";
            request.Source = "RTS";



            data.ApplicationId="123";
            data.BusinessUnit = "1_Europe";
            data.GenerateTicket = "true";
            data.PartyIdPrefix = "103";
            data.Region = "Europe";
            data.ScreeningType = "SANCTION";
            data.TransactionCountry = "France";

                     

        }

       

        [TestMethod]
        public void testToBusinessObjectWhenValidInput()
        {
            var rtsDataLookup = new Mock<IRtsDataLookup<RtsDataLookupDTO>>();
            var rtsRequestValidator = new Mock<IRtsRequestValidator<RtsRequestDTO, DuedilRequestBO>>();
            SanctionAdapter.rtsadapter_transformer.RtsScreenngInput screenInput;
            screenInput = new RtsScreenngInput(rtsDataLookup.Object, rtsRequestValidator.Object);
            rtsDataLookup.Setup(m => m.DataLookup(data));
            rtsRequestValidator.Setup(m => m.validate(It.IsAny<DuedilRequestBO>())).Returns(duedilRequest);
            duedilRequest= screenInput.toBusninessObject(request);

            Assert.IsNotNull(duedilRequest.partyDetail);
            Assert.IsNotNull(duedilRequest.searchAttributes);
            Assert.IsNotNull(duedilRequest.sourceDetail);
            Assert.IsNotNull(duedilRequest);
            Assert.IsNotNull(duedilRequest.sourceDetail.businessUnit);
            Assert.IsNotNull(duedilRequest.sourceDetail.applicationId);
            Assert.IsNotNull(duedilRequest.sourceDetail.orderId);
            Assert.IsNotNull(duedilRequest.searchAttributes.searchDefinition);
            Assert.IsNotNull(duedilRequest.searchAttributes.screeningType);
            Assert.IsNotNull(duedilRequest.searchAttributes.generateTicket);
            Assert.IsNotNull(duedilRequest.searchAttributes.enableSuppression);
            Assert.IsNotNull(duedilRequest.partyDetail.partyId);

            Assert.AreNotEqual("", duedilRequest.sourceDetail.businessUnit);
            Assert.AreNotEqual("", duedilRequest.sourceDetail.applicationId);
            Assert.AreNotEqual("", duedilRequest.sourceDetail.orderId);
            Assert.AreNotEqual("", duedilRequest.searchAttributes.searchDefinition);
            Assert.AreNotEqual("", duedilRequest.searchAttributes.screeningType);
            Assert.AreNotEqual("", duedilRequest.searchAttributes.generateTicket);
            Assert.AreNotEqual("", duedilRequest.searchAttributes.enableSuppression);
            Assert.AreNotEqual("", duedilRequest.partyDetail.partyId);
        }

       
    }
}

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_transformer;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using System.Collections.Generic;
using SanctionAdapter.rtsadapter_model;

namespace UnitTestProject1
{
    [TestClass]
    public class TestRtsSceeningOutput
    {

       
            public MatchBO match;
            public DuedilResponseBO duedilResponse;
           
            public RtsResponseDTO output;
           
        

            [TestInitialize]
            public void setup()
            {
                
                match = new MatchBO();
                duedilResponse = new DuedilResponseBO();
                output = new RtsResponseDTO();
               
                match.remarks = "test";
                match.matchName = "test";
                match.programName = "test";
                match.info = "test";
                match.matchText = "test";
                match.matchType = "test";
                match.partyType = "test";
                match.nameOfSDN = "test";
                match.score = "01";
                match.titleOfSDN = "test";


                duedilResponse.MatchCount = 1;
                duedilResponse.TrackingId = "1234";
                duedilResponse.TicketId = "1234";
                duedilResponse.Matches = new MatchBO[1];
                duedilResponse.Matches[0] = match;

            }

            [TestMethod]
            public void TestToDataTransferObjectWhenVlaidInput()
            {
                SanctionAdapter.rtsadapter_transformer.RtsScreenngOutput screenOutput;

                screenOutput = new RtsScreenngOutput();

                output = screenOutput.toDataTransferObject(duedilResponse);
                Assert.IsNotNull(output.Matches);
                Assert.IsNotNull(output.Message);
                Assert.IsNotNull(output.Outcome);
                Assert.IsNotNull(output.TransId);
                Assert.AreNotEqual("", output.Message);
                Assert.AreNotEqual("", output.Outcome);
                Assert.AreNotEqual("", output.TransId);
            }
        }
    }

﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_dto;
using SanctionAdapter.rtsadapter_model.rtsadapter_model_bo;
using SanctionAdapter.rtsadapter_service;
using SanctionAdapter.rtsadapter_model.rtsadapter_exception;

namespace UnitTestProject1
{
    [TestClass]
    public class TestRtsRequestValidator
    {

       public  RtsRequestDTO rtsRequest;
       public  DuedilRequestBO duedilRequest;
       public  RtsRequestValidator rtsRequestValidator;
       public PartyDetailBO partyDetail;
       public SourceDetailBO sourceDetail;
       public AddressBO address;
       public IdentificationDetailsBO identificationDetails;
       public SearchAttributesBO searchAttributes;

        [TestInitialize]
        public void Setup()
        {
            rtsRequest = new RtsRequestDTO();
            duedilRequest = new DuedilRequestBO();
            rtsRequestValidator = new RtsRequestValidator();

            partyDetail = new PartyDetailBO();
            sourceDetail = new SourceDetailBO();
            address = new AddressBO();
            identificationDetails = new IdentificationDetailsBO();
            searchAttributes = new SearchAttributesBO();

            rtsRequest.Branch = "RTS";
            rtsRequest.Dept="EU";
            rtsRequest.FirstName="Ali";
            rtsRequest.Org="Europe";
            rtsRequest.SanctionRule="EU Sanctions";
            rtsRequest.Source="RTS";


            partyDetail.firstName = "Ali";
            partyDetail.fullName = "Ali";
            partyDetail.partyType = "UNKNOWN";
            partyDetail.partyId = "1234";
            partyDetail.address = address;
            partyDetail.identificationDetails = null;

            sourceDetail.branch = "RTS";
            sourceDetail.country = "UK";
            sourceDetail.organization = "EU Sanctions";
            sourceDetail.businessUnit = "1_Europe";
            sourceDetail.region = "London";
            sourceDetail.applicationId = "R03";
            sourceDetail.orderId = "101";
            sourceDetail.source = "RTS";



            searchAttributes.searchDefinition = "EUSanction";
            searchAttributes.screeningType = "SANCTION";
            searchAttributes.generateTicket = "true";
            searchAttributes.enableSuppression = "false";
            searchAttributes.applyMisspellingRule = "false";
            searchAttributes.mustMatchFields = "a";


            duedilRequest.partyDetail = partyDetail;
            duedilRequest.searchAttributes = searchAttributes;
            duedilRequest.sourceDetail = sourceDetail;

        
        }

        

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForBranchNull()
        {
            rtsRequest.Branch = null;
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForDeptNull()
        {
            rtsRequest.Dept = null;
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForOrgNull()
        {
            rtsRequest.Org = null;
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForFirstNameNull()
        {
            rtsRequest.FirstName = null;
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSanctionRuleNull()
        {
            rtsRequest.SanctionRule = null;
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSourceNull()
        {
            rtsRequest.Source = null;
            rtsRequestValidator.validate(rtsRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForBranchBlank()
        {
            rtsRequest.Branch = "";
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForDeptBlank()
        {
            rtsRequest.Dept = "";
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForOrgBlank()
        {
            rtsRequest.Org = "";
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForFirstNameBlank()
        {
            rtsRequest.FirstName = "";
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSanctionRuleBlank()
        {
            rtsRequest.SanctionRule = "";
            rtsRequestValidator.validate(rtsRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSourceBlank()
        {
            rtsRequest.Source = "";
            rtsRequestValidator.validate(rtsRequest);

        }


        [TestMethod]
        public void TestRtsRequestValidatorForCorrectInput()
        {
           duedilRequest= rtsRequestValidator.validate(duedilRequest);

           Assert.IsNotNull(duedilRequest);
           Assert.IsNotNull(duedilRequest.sourceDetail.businessUnit);
           Assert.IsNotNull(duedilRequest.sourceDetail.applicationId);
           Assert.IsNotNull(duedilRequest.sourceDetail.orderId);
           Assert.IsNotNull(duedilRequest.searchAttributes.searchDefinition);
           Assert.IsNotNull(duedilRequest.searchAttributes.screeningType);
           Assert.IsNotNull(duedilRequest.searchAttributes.generateTicket);
           Assert.IsNotNull(duedilRequest.searchAttributes.enableSuppression);
           Assert.IsNotNull(duedilRequest.partyDetail.partyId);

           Assert.AreNotEqual("",duedilRequest.sourceDetail.businessUnit);
           Assert.AreNotEqual("", duedilRequest.sourceDetail.applicationId);
           Assert.AreNotEqual("", duedilRequest.sourceDetail.orderId);
           Assert.AreNotEqual("", duedilRequest.searchAttributes.searchDefinition);
           Assert.AreNotEqual("", duedilRequest.searchAttributes.screeningType);
           Assert.AreNotEqual("", duedilRequest.searchAttributes.generateTicket);
           Assert.AreNotEqual("", duedilRequest.searchAttributes.enableSuppression);
           Assert.AreNotEqual("", duedilRequest.partyDetail.partyId);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForBusinessUnitNull()
        {
            duedilRequest.sourceDetail.businessUnit = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForApplicationIdNull()
        {
            duedilRequest.sourceDetail.applicationId = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForOderIdNull()
        {
            duedilRequest.sourceDetail.orderId = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSearchDefinationNull()
        {
            duedilRequest.searchAttributes.searchDefinition = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForScreeningTypeNull()
        {
            duedilRequest.searchAttributes.screeningType = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForGenerateTicketNull()
        {
            duedilRequest.searchAttributes.generateTicket = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForEnableSupressionNull()
        {
            duedilRequest.searchAttributes.enableSuppression = null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForPartyIdNull()
        {
            duedilRequest.partyDetail.partyId= null;
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForBusinessUnitBlank()
        {
            duedilRequest.sourceDetail.businessUnit = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForApplicationIdBlank()
        {
            duedilRequest.sourceDetail.applicationId = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForOderIdBlank()
        {
            duedilRequest.sourceDetail.orderId = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForSearchDefinationBlank()
        {
            duedilRequest.searchAttributes.searchDefinition = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForScreeningTypeBlank()
        {
            duedilRequest.searchAttributes.screeningType = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForGenerateTicketBlank()
        {
            duedilRequest.searchAttributes.generateTicket = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForEnableSupressionBlank()
        {
            duedilRequest.searchAttributes.enableSuppression = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForPartyIdBlank()
        {
            duedilRequest.partyDetail.partyId = "";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidInputException))]
        public void TestRtsRequestValidatorForPartyIdLengthGreaterThan50()
        {
            duedilRequest.partyDetail.partyId = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);          

        }

        [TestMethod]
        public void TestRtsRequestValidatorForPartyIdLengthLessThan50()
        {
            duedilRequest.partyDetail.partyId = "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvw";
            duedilRequest = rtsRequestValidator.validate(duedilRequest);

        }


    }
}

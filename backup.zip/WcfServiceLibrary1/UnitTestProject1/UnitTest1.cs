﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            PrimeRequest rtsRequestDTO = new PrimeRequest();

            //rtsRequestDTO.FirstName = null;
            //rtsRequestDTO.Branch = null;
            //rtsRequestDTO.City = null;
            //rtsRequestDTO.Country = null;
            //rtsRequestDTO.DateOfBirth = null;
            //rtsRequestDTO.Dept = null;
            //rtsRequestDTO.Org = null;
            //rtsRequestDTO.SanctionRule = null;
            //rtsRequestDTO.Source = null;
            //rtsRequestDTO.Street = null;
            //rtsRequestDTO.User = null;
            
            Assert.IsNotNull(rtsRequestDTO.FirstName);
        }
    }
}

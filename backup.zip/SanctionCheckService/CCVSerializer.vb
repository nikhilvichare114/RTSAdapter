Imports System.IO
Imports System.Xml
Imports System.Xml.Serialization

<Runtime.InteropServices.ComVisible(False)> _
Friend Class CCVSerializer
    Implements IDisposable

    Friend Shared Function Serialize(Of X)(ByVal myRequest As X) As String
        Dim serializer As XmlSerializer
        Dim customNamespaces As XmlSerializerNamespaces
        Dim sbXMLRequest As New Text.StringBuilder
        Dim xmlwtr As XmlWriter
        Try
            ' Namespace for the serialization message.
            customNamespaces = New XmlSerializerNamespaces()
            customNamespaces.Add("", "http://www.nrf-arts.org/IXRetail/namespace")

            ' Create an XmlSerializer object to perform the serialization of an object of type X.
            serializer = New XmlSerializer(GetType(X))

            ' Create a new stringbuilder to write the XML Request message to.
            sbXMLRequest = New Text.StringBuilder
            '-----------------------------------------------------
            ' Create the xml writer settings to format the xml as needed.
            Dim xmlwtrSettings As New System.Xml.XmlWriterSettings()
            'xmlwtrSettings.OmitXmlDeclaration = True ' remove <?xml version="1.0" encoding="utf-8" ?> .
            xmlwtrSettings.Encoding = System.Text.Encoding.UTF8 ' set the encoding type.
            'xmlwtrSettings.Indent = True ' set to indent the message.
            '-----------------------------------------------------
            ' Create a XML writer using the settings to write to the stringbuilder sbXMLRequest.
            xmlwtr = XmlWriter.Create(sbXMLRequest, xmlwtrSettings)
            ' Use the XmlSerializer object to serialize the object of type X to the stringbuilder. 
            serializer.Serialize(xmlwtr, myRequest, customNamespaces)
            xmlwtr.Close()

            sbXMLRequest.Replace("utf-16", "utf-8")
            Return sbXMLRequest.ToString
        Catch ex As Exception
            Throw ex

        Finally
            serializer = Nothing
            customNamespaces = Nothing
            sbXMLRequest = Nothing
            xmlwtr = Nothing
        End Try
    End Function

    'Friend Shared Function Serialize(Of X)(ByVal myRequest As X) As IO.MemoryStream

    '  Try
    '    Dim formatter As New Runtime.Serialization.Formatters.Binary.BinaryFormatter()
    '    Dim memStream As New MemoryStream()
    '    ' serialize current object
    '    formatter.Serialize(memStream, GetType(X))
    '    Return memStream

    '  Catch ex As Exception
    '    Throw ex

    '  Finally

    '  End Try
    'End Function

    Friend Shared Function Deserialize(Of Y)(ByVal strXMLResponse As String, ByRef Response As Y) As Boolean

        Try
            ' Create a XML reader to read to the stringbuilder sbXMLRequest.
            Dim xmlrdr As XmlReader = XmlReader.Create(New System.IO.StringReader(strXMLResponse))
            ' Create an XmlSerializer object to perform the deserialization
            Dim serializer As New XmlSerializer(GetType(Y))
            If serializer.CanDeserialize(xmlrdr) Then
                ' Use the XmlSerializer object to deserialize the data
                Response = CType(serializer.Deserialize(xmlrdr), Y)
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Throw ex
        End Try

    End Function



    Private disposedValue As Boolean = False    ' To detect redundant calls

    ' IDisposable
    Protected Overridable Sub Dispose(ByVal disposing As Boolean)
        If Not Me.disposedValue Then
            If disposing Then
                ' TODO: free managed resources when explicitly called
            End If

            ' TODO: free shared unmanaged resources
        End If
        Me.disposedValue = True
    End Sub

#Region " IDisposable Support "
    ' This code added by Visual Basic to correctly implement the disposable pattern.
    Public Sub Dispose() Implements IDisposable.Dispose
        ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
        Dispose(True)
        GC.SuppressFinalize(Me)
    End Sub
#End Region

End Class

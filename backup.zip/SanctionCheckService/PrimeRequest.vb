<System.Runtime.InteropServices.ComVisible(False)> _
Public Class PrimeRequest

    Private _FirstName As String
    Private _MiddleName As String
    Private _LastName As String
    Private _DateOfBirth As String
    Private _Street As String
    Private _City As String
    Private _Country As String
    Private _User As String
    Private _Password As String
    Private _Org As String
    Private _Branch As String
    Private _Dept As String
    Private _Source As String
    Private _SanctionRule As String

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal FirstName As String, ByVal MiddleName As String, ByVal LastName As String, ByVal DateOfBirth As String, ByVal Street As String, ByVal City As String, ByVal Country As String, ByVal User As String, ByVal Password As String, ByVal Org As String, ByVal Branch As String, ByVal Dept As String, ByVal Source As String, ByVal SanctionRule As String)
        Me._FirstName = FirstName
        Me._MiddleName = MiddleName
        Me._LastName = LastName
        Me._DateOfBirth = DateOfBirth
        Me._Street = Street
        Me._City = City
        Me._Country = Country
        Me._User = User
        Me._Password = Password
        Me._Org = Org
        Me._Branch = Branch
        Me._Dept = Dept
        Me._Source = Source
        Me._SanctionRule = SanctionRule
    End Sub


    Public Property FirstName() As String
        Get
            Return _FirstName
        End Get
        Set(ByVal Value As String)
            _FirstName = Value
        End Set
    End Property
    Public Property MiddleName() As String
        Get
            Return _MiddleName
        End Get
        Set(ByVal Value As String)
            _MiddleName = Value
        End Set
    End Property

    Public Property LastName() As String
        Get
            Return _LastName
        End Get
        Set(ByVal Value As String)
            _LastName = Value
        End Set
    End Property

    Public Property DateOfBirth() As String
        Get
            Return _DateOfBirth
        End Get
        Set(ByVal Value As String)
            _DateOfBirth = Value
        End Set
    End Property

    Public Property Street() As String
        Get
            Return _Street
        End Get
        Set(ByVal Value As String)
            _Street = Value
        End Set
    End Property

    Public Property City() As String
        Get
            Return _City
        End Get
        Set(ByVal Value As String)
            _City = Value
        End Set
    End Property

    Public Property Country() As String
        Get
            Return _Country
        End Get
        Set(ByVal Value As String)
            _Country = Value
        End Set
    End Property

    Public Property User() As String
        Get
            Return _User
        End Get
        Set(ByVal Value As String)
            _User = Value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return _Password
        End Get
        Set(ByVal Value As String)
            _Password = Value
        End Set
    End Property

    Public Property Org() As String
        Get
            Return _Org
        End Get
        Set(ByVal Value As String)
            _Org = Value
        End Set
    End Property

    Public Property Branch() As String
        Get
            Return _Branch
        End Get
        Set(ByVal Value As String)
            _Branch = Value
        End Set
    End Property

    Public Property Dept() As String
        Get
            Return _Dept
        End Get
        Set(ByVal Value As String)
            _Dept = Value
        End Set
    End Property

    Public Property Source() As String
        Get
            Return _Source
        End Get
        Set(ByVal Value As String)
            _Source = Value
        End Set
    End Property

    Public Property SanctionRule() As String
        Get
            Return _SanctionRule
        End Get
        Set(ByVal Value As String)
            _SanctionRule = Value
        End Set
    End Property

End Class

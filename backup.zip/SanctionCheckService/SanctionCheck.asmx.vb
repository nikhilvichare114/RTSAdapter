Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
Imports System.Xml
Imports SanctionAdapter.rtsadapter_model
Imports SanctionAdapter.rtsadapter_service

<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> <System.Runtime.InteropServices.ComVisible(False)> _
Public Class SanctionCheck
    Inherits System.Web.Services.WebService

    <WebMethod()>
    Public Function GetCustomerMatch(ByVal PrimeReq As PrimeRequest) As PrimeResponse

       
        Dim intIterator As Integer
        Dim strMatchName As String
        Dim strMatchList As String
        Dim strMatchRemarks As String

        Dim SerResponse As New GETSEARCHRESULTS
        Dim PrimeMatches As New PrimeResponse
        Dim OFACService As New PrimeServer.OFACReporterWS

        

        Dim actimizeRequest As New rtsadapter_model_dto.RtsRequestDTO
        Dim actimizeResponse As New rtsadapter_model_dto.RtsResponseDTO

        Try
            OFACService.Credentials = System.Net.CredentialCache.DefaultCredentials

            actimizeRequest.Branch = PrimeReq.Branch
            actimizeRequest.City = PrimeReq.City
            actimizeRequest.Country = PrimeReq.Country
            actimizeRequest.DateOfBirth = PrimeReq.DateOfBirth
            actimizeRequest.Dept = PrimeReq.Dept
            actimizeRequest.FirstName = PrimeReq.FirstName
            actimizeRequest.LastName = PrimeReq.LastName
            actimizeRequest.MiddleName = PrimeReq.MiddleName
            actimizeRequest.Org = PrimeReq.Org
            actimizeRequest.Password = PrimeReq.Password
            actimizeRequest.SanctionRule = PrimeReq.SanctionRule
            actimizeRequest.Source = PrimeReq.Source
            actimizeRequest.Street = PrimeReq.Street
            actimizeRequest.User = PrimeReq.User

            Dim SanctionChkService As New SanctionAdapter.SanctionCheckService()
            actimizeResponse = SanctionChkService.GetCustomerMatch(actimizeRequest)

            If Not IsNothing(actimizeResponse.Matches) Then
                If actimizeResponse.Matches.Count > 0 Then
                    PrimeMatches.Matches = New SanctionInfo(actimizeResponse.Matches.Count - 1) {}
                    intIterator = 0
                    Dim loopCnt As Integer
                    For loopCnt = 0 To actimizeResponse.Matches.Count - 1
                        strMatchName = actimizeResponse.Matches(loopCnt).MatchName
                        strMatchList = actimizeResponse.Matches(loopCnt).ListType
                        strMatchRemarks = actimizeResponse.Matches(loopCnt).Remarks
                        PrimeMatches.Matches(intIterator) = New SanctionInfo(strMatchName, strMatchList, strMatchRemarks)
                        intIterator = intIterator + 1
                    Next

                End If
            End If

            PrimeMatches.Outcome = actimizeResponse.Outcome

            PrimeMatches.Message = actimizeResponse.Message
            PrimeMatches.TransId = actimizeResponse.TransId

            Return PrimeMatches

        Catch ex As Exception

            Return New PrimeResponse(MessageOutcome.Failed, ex.Message)
        End Try

    End Function

    Public Sub New()

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub



End Class
﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;
using SanctionCheck.rtsadapter_model.rtsadapter_exception;
using SanctionCheck.rtsadapter_service.;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void primeRequestTestForNotNull()
        {
            PrimeRequest rtsRequestDTO = new PrimeRequest();

            rtsRequestDTO.FirstName = "Ali";
            rtsRequestDTO.Dept = "EU";
            rtsRequestDTO.Org = "Europe";
            rtsRequestDTO.SanctionRule = "EU Sanctions";
            rtsRequestDTO.Source = "RTS";
           
            Assert.IsNotNull(rtsRequestDTO.FirstName);
            Assert.IsNotNull(rtsRequestDTO.Dept);
            Assert.IsNotNull(rtsRequestDTO.Org);
            Assert.IsNotNull(rtsRequestDTO.SanctionRule);
            Assert.IsNotNull(rtsRequestDTO.Source);

        }
        [TestMethod]
        [ExpectedException(typeof(InvalidInputException),"Missing First Name")]
        public void primeRequestTestForFirstNameNull()
        {
            PrimeRequest rtsRequestDTO = new PrimeRequest();
           
            rtsRequestDTO.FirstName = null;
            rtsRequestDTO.Dept = "EU";
            rtsRequestDTO.Org = "Europe";
            rtsRequestDTO.SanctionRule = "EU Sanctions";
            rtsRequestDTO.Source = "RTS";
           
                     
            Assert.IsNotNull(rtsRequestDTO.Dept);
            Assert.IsNotNull(rtsRequestDTO.Org);
            Assert.IsNotNull(rtsRequestDTO.SanctionRule);
            Assert.IsNotNull(rtsRequestDTO.Source);

        }
    }
}

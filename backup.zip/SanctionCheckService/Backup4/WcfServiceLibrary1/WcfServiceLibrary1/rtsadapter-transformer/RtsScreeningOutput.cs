using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_data_access;
using SanctionCheck.rtsadapter_model;
using SanctionCheck.rtsadapter_model.rtsadapter_model_bo;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionCheck.rtsadapter_transformer
{
    public class RtsScreenngOutput : BoDtoFactory<DuedilResponseBO, PrimeResponse>
    {
        public DuedilResponseBO toBusninessObject(PrimeResponse response)
        {
            throw new NotImplementedException();
        }

        public PrimeResponse toDataTransferObject(DuedilResponseBO response)
        {
            PrimeResponse rtsResponse = new PrimeResponse();
            List<SanctionInfoDTO> sanctionInfo = new List<SanctionInfoDTO>();
           
            try
            {
                if (response.Equals(null))
                {
                    throw new NullReferenceException();

                }
                else
                {
                    rtsResponse.TransId = response.TrackingId;
                    foreach (MatchBO match in response.Matches)
                    {
                        SanctionInfoDTO sanctionData = new SanctionInfoDTO();
                        sanctionData.MatchName = match.matchName;
                        sanctionData.ListType = match.programName;
                        sanctionData.Remarks = match.remarks;
                        sanctionInfo.Add(sanctionData);

                    }
                    rtsResponse.Matches = sanctionInfo;

                    if (response.MatchCount > 0)
                    {
                        rtsResponse.Outcome = MessageOutcome.MatchesFound;
                        rtsResponse.Message = "Web Service Ok";
                    }
                    else
                    {
                        rtsResponse.Outcome = MessageOutcome.NoMatches;
                        rtsResponse.Message = "Web Service Ok";
                    }

                }
            }

            catch (NullReferenceException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }
            
            return rtsResponse;
        }
    }
}
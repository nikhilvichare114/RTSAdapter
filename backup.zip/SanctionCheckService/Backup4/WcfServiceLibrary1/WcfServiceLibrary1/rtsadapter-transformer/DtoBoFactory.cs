﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_transformer
{
   public interface DtoBoFactory<RtsRequestDTO,DuedilRequestBO>
    {
         DuedilRequestBO toBusninessObject(RtsRequestDTO request);

         RtsRequestDTO toDataTransferObject(DuedilRequestBO request);
    }
}

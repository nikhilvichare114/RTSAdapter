﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionCheck.rtsadapter_data_access
{
   public interface RtsDataLookup<RtsDataLookupDTO>
    {
       RtsDataLookupDTO datalookup(RtsDataLookupDTO data);
    }
}

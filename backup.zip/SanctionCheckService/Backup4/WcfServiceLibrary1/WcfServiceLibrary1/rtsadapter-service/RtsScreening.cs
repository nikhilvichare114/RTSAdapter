﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SanctionCheck.rtsadapter_model;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;

namespace SanctionCheck.rtsadapter_service
{
    public interface RtsScreening<RtsRequestDTO>
    {
        PrimeResponse screening(RtsRequestDTO request);
    }

}

﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SanctionCheck.rtsadapter_data_access;
using SanctionCheck.rtsadapter_model;
using SanctionCheck.rtsadapter_model.rtsadapter_exception;
using SanctionCheck.rtsadapter_model.rtsadapter_model_dto;
using SanctionCheck.rtsadapter_transformer;

namespace SanctionCheck.rtsadapter_service
{
    class RtsScreeningImpl : RtsScreening<PrimeRequest>
    {
        public PrimeResponse screening(PrimeRequest request)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            PrimeResponse response = new PrimeResponse();
            DuedilResponseBO service = new DuedilResponseBO();
            RtsScreenngInput rtsScreening = new RtsScreenngInput();
            HttpClient client = new HttpClient();
            try
            {
                var duedilInputRequest = rtsScreening.toBusninessObject(request);
                string URL = ConfigurationManager.AppSettings["MockDuedil"];
                string cacheControl = ConfigurationManager.AppSettings["cache-control"];
                string XAuth = ConfigurationManager.AppSettings["X-Auth"];
                client.BaseAddress = new Uri(URL);
                client.DefaultRequestHeaders.Add("cache-control", cacheControl);
                client.DefaultRequestHeaders.Add("X-Auth", XAuth);
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "App");
              
                HttpContent content = new StringContent(JsonConvert.SerializeObject(duedilInputRequest), Encoding.UTF8, "application/json");                

                var duedilResponse = client.PostAsync(URL,content).Result;                
                string duedilResponseResult = duedilResponse.Content.ReadAsStringAsync().Result.ToString();
                int statusCode = (int)duedilResponse.StatusCode;
                
                if (statusCode.Equals(200) || statusCode.Equals(202))
                {

                    service = JsonConvert.DeserializeObject<DuedilResponseBO>(duedilResponseResult);

                    RtsScreenngOutput rtsScreeningOutput = new RtsScreenngOutput();
                    response = rtsScreeningOutput.toDataTransferObject(service);
                }
                else
                {
                    throw new HttpRequestException("Duedil Response Error : " + " " + duedilResponseResult);
                }


            }
            catch (InvalidInputException ex)
            {
                throw ex;
            }
            catch (NullReferenceException ex)
            {

                throw ex;
            }

            catch (SqlException ex)
            {
                throw ex;

            }

            catch (HttpRequestException ex)
            {
                throw ex;

            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                
            
            }
            return response;
        }
    }
}

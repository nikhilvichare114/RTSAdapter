﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
   public class SourceDetailBO
    {
        public string organization { get; set; }
        public string businessUnit { get; set; }
        public string region { get; set; }
        public string branch { get; set; }
        public string country { get; set; }
        public string applicationId { get; set; }
        public string source { get; set; }
        public string orderId { get; set; }
    }
}

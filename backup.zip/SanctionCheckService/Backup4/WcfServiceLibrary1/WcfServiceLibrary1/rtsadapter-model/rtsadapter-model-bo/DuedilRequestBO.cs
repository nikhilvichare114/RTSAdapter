﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
    public class DuedilRequestBO
    {
      
            public SourceDetailBO sourceDetail { get; set; }
            public SearchAttributesBO searchAttributes { get; set; }
            public PartyDetailBO partyDetail { get; set; }
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_bo
{
   public class PartyDetailBO
    {
        public string partyId { get; set; }
        public string partyType { get; set; }
        public string fullName { get; set; }
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public string dateOfBirth { get; set; }
        public AddressBO address { get; set; }
        public IdentificationDetailsBO[] identificationDetails { get; set; }
    }
}

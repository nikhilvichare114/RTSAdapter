﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_dto
{
    public class SanctionInfoDTO
    {
        
        public string MatchName{get;set;}
        public string ListType{get;set;}
        public string Remarks{get;set;}

    }
}

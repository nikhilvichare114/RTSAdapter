﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_dto
{
  public  class RtsDataLookupDTO
    {

    public string TransctionCountry {get;set;} 

	public string Region {get;set;} 

	public string SanctionRule {get;set;} 

	public string BusinessUnit {get;set;} 

	public string ApplicationId {get;set;}

	public string ScreeningType {get;set;}

	public string GenerateTicket {get;set;}

	public string PartyIdPrefix  {get;set;}

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanctionCheck.rtsadapter_model.rtsadapter_model_dto
{
   public class RtsErrorDTO
    {
       public int errorCode { get; set; }
       public string duedilErrorCode { get; set; }
       public string duedilErrorMessage { get; set; }
    }
}

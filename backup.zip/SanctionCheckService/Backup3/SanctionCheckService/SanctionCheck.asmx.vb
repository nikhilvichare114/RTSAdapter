Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports System.ComponentModel
'Imports System.IO
Imports System.Xml

<System.Web.Services.WebService(Namespace:="http://tempuri.org/")> _
<System.Web.Services.WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<ToolboxItem(False)> <System.Runtime.InteropServices.ComVisible(False)> _
Public Class SanctionCheck
    Inherits System.Web.Services.WebService

    <WebMethod()> _
    Public Function GetCustomerMatch(ByVal PrimeReq As PrimeRequest) As PrimeResponse

        Dim strErrorDesc As String
        Dim strErrorNum As String
        Dim strParam As String
        Dim strResults As String
        Dim intIterator As Integer
        Dim intMatchCount As Integer
        Dim strMatchName As String
        Dim strMatchList As String
        Dim strMatchRemarks As String

        Dim SerResponse As New GETSEARCHRESULTS
        Dim PrimeMatches As New PrimeResponse
        Dim OFACService As New PrimeServer.OFACReporterWS

        Try
            OFACService.Credentials = System.Net.CredentialCache.DefaultCredentials

            strParam = "<?xml version=""1.0"" encoding=""utf-8""?> " & _
              "<n:GETSEARCHRESULTS xmlns:n=""www.primeassociates.com/ComplianceManager/OFACReporter"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" >" & _
                 "<n:INPUT> " & _
                     "<n:ORGANIZATION>" & PrimeReq.Org & "</n:ORGANIZATION>" & _
                     "<n:BRANCH>" & PrimeReq.Branch & "</n:BRANCH>" & _
                     "<n:DEPT>" & PrimeReq.Dept & "</n:DEPT>" & _
                     "<n:SOURCE>" & PrimeReq.Source & "</n:SOURCE>" & _
                     "<n:FILEIMG>" & PrimeReq.SanctionRule & "</n:FILEIMG>" & _
                     "<n:USEDB>false</n:USEDB>" & _
                     "<n:DELEGATED>false</n:DELEGATED>" & _
                     "<n:RETURNORIGINALREQUEST>false</n:RETURNORIGINALREQUEST>" & _
                     "<n:SEARCHDATA>" & _
                         "<n:PARTYID></n:PARTYID>" & _
                         "<n:PARTYNAME n:USETEXTEXCLUDE=""true"" n:ALGORITHM=""MatchFullName"" n:MISSPELLING=""false"" n:MUSTMATCHTYPE=""PARTYNAME,KEYWORD"" n:MUSTALSOMATCHTYPE=""AllOf"" n:MUSTALSOMATCHFIELDS=""STREET,CITY,COUNTRY,DATEOFBIRTH"" >" & _
                         "<n:FULLNAME>" & PrimeReq.FirstName & " " & PrimeReq.MiddleName & " " & PrimeReq.LastName & "</n:FULLNAME></n:PARTYNAME>" & _
                         "<n:PARTYADDRESS>" & _
                         "<n:STREET n:ALGORITHM=""None"" n:MISSPELLING=""true"" n:USETEXTEXCLUDE=""true"" n:MUSTMATCHTYPE=""STREETADDRESS"" n:MUSTALSOMATCHTYPE=""AllOf"" n:MUSTALSOMATCHFIELDS=""CITY,COUNTRY,DATEOFBIRTH"">" & PrimeReq.Street & "</n:STREET>" & _
                         "<n:CITY n:ALGORITHM=""None"" n:MISSPELLING=""true"" n:USETEXTEXCLUDE=""true"" n:MUSTMATCHTYPE=""CITY"" n:MUSTALSOMATCHTYPE=""AllOf"" n:MUSTALSOMATCHFIELDS=""STREET,COUNTRY,DATEOFBIRTH"">" & PrimeReq.City & "</n:CITY>" & _
                         "<n:STATE n:ALGORITHM=""None"" n:MISSPELLING=""true"" n:USETEXTEXCLUDE=""true"" ></n:STATE>" & _
                         "<n:POSTALCODE></n:POSTALCODE>" & _
                         "<n:COUNTRY n:ALGORITHM=""None"" n:MISSPELLING=""true"" n:USETEXTEXCLUDE=""true"" n:MUSTMATCHTYPE=""COUNTRY"" n:MUSTALSOMATCHTYPE=""AllOf"" n:MUSTALSOMATCHFIELDS=""STREET,CITY,DATEOFBIRTH"">" & PrimeReq.Country & "</n:COUNTRY>" & _
                         "</n:PARTYADDRESS>" & _
                         "<n:DATEOFBIRTH n:ALGORITHM=""None"" n:MISSPELLING=""true"" n:USETEXTEXCLUDE=""true"" n:MUSTALSOMATCHTYPE=""AllOf"" n:MUSTALSOMATCHFIELDS=""STREET,CITY,COUNTRY"">" & PrimeReq.DateOfBirth & "</n:DATEOFBIRTH>" & _
                     "</n:SEARCHDATA>" & _
                 "</n:INPUT> " & _
             "</n:GETSEARCHRESULTS>"

            ' Call the OFAC Reporter web service
            strResults = OFACService.getSearchResults(PrimeReq.User, PrimeReq.Password, PrimeReq.Org, strParam)

            If CCVSerializer.Deserialize(strResults, SerResponse) Then
                ' System Exception setup
                PrimeMatches.Outcome = MessageOutcome.Failed
                PrimeMatches.Message = "Unknown XML format in response"

                ' Error returned from web service
                If UBound(SerResponse.OUTPUT().ItemsElementName()) = 0 Then
                    If SerResponse.OUTPUT().ItemsElementName(0) = ItemsChoiceType1.ERROR Then
                        strErrorNum = SerResponse.OUTPUT().Items(0).ERRORNUM
                        strErrorDesc = SerResponse.OUTPUT().Items(0).ERRORDESC
                        PrimeMatches.Outcome = MessageOutcome.Failed
                        PrimeMatches.Message = strErrorNum & " " & strErrorDesc
                    End If
                End If

                ' Search results returned from web service
                If UBound(SerResponse.OUTPUT().ItemsElementName()) > 0 Then
                    If SerResponse.OUTPUT().ItemsElementName(1) = ItemsChoiceType1.MATCHES Then
                        intMatchCount = CInt(SerResponse.OUTPUT().Items(1).Count())
                        If intMatchCount > 0 Then
                            PrimeMatches.Matches = New SanctionInfo(intMatchCount - 1) {}
                            intIterator = 0
                            Dim loopCnt As Integer
                            For loopCnt = 0 To intMatchCount - 1
                                strMatchName = SerResponse.OUTPUT().Items(1).Match(loopCnt).ORIGINALSDNNAME
                                strMatchList = SerResponse.OUTPUT().Items(1).Match(loopCnt).MATCHPROGRAM
                                strMatchRemarks = SerResponse.OUTPUT().Items(1).Match(loopCnt).MATCHREMARKS
                                PrimeMatches.Matches(intIterator) = New SanctionInfo(strMatchName, strMatchList, strMatchRemarks)
                                intIterator = intIterator + 1
                            Next
                            PrimeMatches.Outcome = MessageOutcome.MatchesFound
                            PrimeMatches.Message = "Web Service Ok"
                        Else
                            PrimeMatches.Outcome = MessageOutcome.NoMatches
                            PrimeMatches.Message = "Web Service Ok"
                        End If
                    End If
                    If SerResponse.OUTPUT().ItemsElementName(0) = ItemsChoiceType1.TRANSACTIONID Then
                        PrimeMatches.TransId = SerResponse.OUTPUT().Items(0)
                    End If
                End If
            End If

            Return PrimeMatches

        Catch ex As Exception
            Return New PrimeResponse(MessageOutcome.Failed, ex.Message)
        End Try

    End Function

    Public Sub New()

    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub

End Class

<System.Runtime.InteropServices.ComVisible(False)> _
Public Enum MessageOutcome
    Failed = 1
    NoMatches = 2
    MatchesFound = 3
End Enum


<System.Runtime.InteropServices.ComVisible(False)> _
Public Class PrimeResponse

    Private TransIdField As String
    Private SanctionField() As SanctionInfo
    Private OutcomeField As MessageOutcome
    Private MessageField As String

    Public Sub New()
        MyBase.New()
    End Sub

    Public Sub New(ByVal Outcome As MessageOutcome, ByVal Message As String)
        OutcomeField = Outcome
        MessageField = Message
    End Sub

    Public Property TransId() As String
        Get
            Return TransIdField
        End Get
        Set(ByVal Value As String)
            TransIdField = Value
        End Set
    End Property

    Public Property Matches() As SanctionInfo()
        Get
            Return Me.SanctionField
        End Get
        Set(ByVal value As SanctionInfo())
            Me.SanctionField = value
        End Set
    End Property
    '''<remarks/>
    Public Property Outcome() As MessageOutcome
        Get
            Return Me.OutcomeField
        End Get
        Set(ByVal value As MessageOutcome)
            Me.OutcomeField = value
        End Set
    End Property

    '''<remarks/>
    Public Property Message() As String
        Get
            Return Me.MessageField
        End Get
        Set(ByVal value As String)
            Me.MessageField = value
        End Set
    End Property

End Class


'SanctionInfo class
<System.Runtime.InteropServices.ComVisible(False)> _
Public Class SanctionInfo

    Private _MatchName As String
    Private _ListType As String
    Private _Remarks As String


    Public Sub New(ByVal MatchName As String, ByVal ListType As String, ByVal Remarks As String)
        Me._MatchName = MatchName
        Me._ListType = ListType
        Me._Remarks = Remarks
    End Sub

    Public Sub New()
        MyBase.New()
    End Sub

    Public Property MatchName() As String
        Get
            Return _MatchName
        End Get
        Set(ByVal Value As String)
            _MatchName = Value
        End Set
    End Property

    Public Property ListType() As String
        Get
            Return _ListType
        End Get
        Set(ByVal Value As String)
            _ListType = Value
        End Set
    End Property

    Public Property Remarks() As String
        Get
            Return _Remarks
        End Get
        Set(ByVal Value As String)
            _Remarks = Value
        End Set
    End Property

End Class
